package ds;

import java.util.Iterator;
import java.util.NoSuchElementException;
import model.enumPozice;

public class AbstrDoubleList<T> implements IAbstrDoubleList<T> {
    private class Node {
        T data;
        Node prev, next;
        Node(T data) { this.data = data; }
    }

    private Node head, tail, aktualni;
    private int size = 0;

    @Override
    public void zrus() { head = tail = aktualni = null; size = 0; }
    @Override
    public boolean jePrazdny() { return size == 0; }
    @Override
    public void vlozPrvni(T data) {
        Node n = new Node(data);
        if (head == null) head = tail = n;
        else { n.next = head; head.prev = n; head = n; }
        aktualni = n;
        size++;
    }
    @Override
    public void vlozPosledni(T data) {
        Node n = new Node(data);
        if (tail == null) head = tail = n;
        else { n.prev = tail; tail.next = n; tail = n; }
        aktualni = n;
        size++;
    }
    @Override
    public void vlozNaslednika(T data) {
        if (aktualni == null) throw new IllegalStateException();
        Node n = new Node(data);
        n.prev = aktualni;
        n.next = aktualni.next;
        if (aktualni.next != null) aktualni.next.prev = n;
        aktualni.next = n;
        if (aktualni == tail) tail = n;
        aktualni = n;
        size++;
    }
    @Override
    public void vlozPredchudce(T data) {
        if (aktualni == null) throw new IllegalStateException();
        Node n = new Node(data);
        n.next = aktualni;
        n.prev = aktualni.prev;
        if (aktualni.prev != null) aktualni.prev.next = n;
        aktualni.prev = n;
        if (aktualni == head) head = n;
        aktualni = n;
        size++;
    }
    @Override
    public T zpristupniAktualni() {
        if (aktualni == null) throw new NoSuchElementException();
        return aktualni.data;
    }
    @Override
    public T zpristupniPrvni() {
        if (head == null) throw new NoSuchElementException();
        aktualni = head;
        return head.data;
    }
    @Override
    public T zpristupniPosledni() {
        if (tail == null) throw new NoSuchElementException();
        aktualni = tail;
        return tail.data;
    }
    @Override
    public T zpristupniNaslednika() {
        if (aktualni == null || aktualni.next == null) throw new NoSuchElementException();
        aktualni = aktualni.next;
        return aktualni.data;
    }
    @Override
    public T zpristupniPredchudce() {
        if (aktualni == null || aktualni.prev == null) throw new NoSuchElementException();
        aktualni = aktualni.prev;
        return aktualni.data;
    }
    @Override
    public T odeberAktualni() {
        if (aktualni == null) throw new NoSuchElementException();
        T data = aktualni.data;
        Node next = aktualni.next, prev = aktualni.prev;
        if (prev != null) prev.next = next; else head = next;
        if (next != null) next.prev = prev; else tail = prev;
        size--;
        aktualni = head;
        return data;
    }
    @Override
    public T odeberPrvni() {
        if (head == null) throw new NoSuchElementException();
        aktualni = head;
        return odeberAktualni();
    }
    @Override
    public T odeberPosledni() {
        if (tail == null) throw new NoSuchElementException();
        aktualni = tail;
        return odeberAktualni();
    }
    @Override
    public T odeberNaslednika() {
        if (aktualni == null || aktualni.next == null) throw new NoSuchElementException();
        Node n = aktualni.next;
        aktualni = n;
        return odeberAktualni();
    }
    @Override
    public T odeberPredchudce() {
        if (aktualni == null || aktualni.prev == null) throw new NoSuchElementException();
        Node n = aktualni.prev;
        aktualni = n;
        return odeberAktualni();
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            Node current = head;
            public boolean hasNext() { return current != null; }
            public T next() {
                if (!hasNext()) throw new NoSuchElementException();
                T data = current.data;
                current = current.next;
                return data;
            }
        };
    }

    // NOV� METODY:
    @Override
    public T zpristupniZaznam(enumPozice pozice) {
        switch (pozice) {
            case PRVNI: return zpristupniPrvni();
            case POSLEDNI: return zpristupniPosledni();
            case NASLEDNIK: return zpristupniNaslednika();
            case PREDCHUDCE: return zpristupniPredchudce();
            case AKTUALNI: return zpristupniAktualni();
            default: throw new IllegalArgumentException("Nezn�m� pozice");
        }
    }

    @Override
    public T odeberZaznam(enumPozice pozice) {
        switch (pozice) {
            case PRVNI: return odeberPrvni();
            case POSLEDNI: return odeberPosledni();
            case NASLEDNIK: return odeberNaslednika();
            case PREDCHUDCE: return odeberPredchudce();
            case AKTUALNI: return odeberAktualni();
            default: throw new IllegalArgumentException("Nezn�m� pozice");
        }
    }
}