/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Zaznam {
    private final int id;
    private final String jmeno;

    public Zaznam(int id, String jmeno) {
        this.id = id;
        this.jmeno = jmeno;
    }

    public int getId() { return id; }
    public String getJmeno() { return jmeno; }

    @Override
    public String toString() {
        return "Zaznam[id=" + id + ", jmeno=" + jmeno + "]";
    }
}
