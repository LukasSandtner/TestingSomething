/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import ds.AbstrDoubleList;

public class Oblast {
    private final int id;
    private final int maxKapacita;
    private int aktKapacita;
    private final AbstrDoubleList<Zaznam> zaznamy = new AbstrDoubleList<>();

    public Oblast(int id, int maxKapacita) {
        this.id = id;
        this.maxKapacita = maxKapacita;
        this.aktKapacita = 0;
    }

    public int getId() { return id; }
    public int getMaxKapacita() { return maxKapacita; }
    public int getAktKapacita() { return aktKapacita; }
    public AbstrDoubleList<Zaznam> getZaznamy() { return zaznamy; }

    public boolean jePlna() { return aktKapacita >= maxKapacita; }
    public void zvysKapacitu() { aktKapacita++; }
    public void snizKapacitu() { aktKapacita--; }

    @Override
    public String toString() {
        return "Oblast[id=" + id + ", max=" + maxKapacita + ", akt=" + aktKapacita + "]";
    }
}
