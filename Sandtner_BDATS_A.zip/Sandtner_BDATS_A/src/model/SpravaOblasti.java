/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import ds.AbstrDoubleList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SpravaOblasti implements ISpravaOblasti {
    private final AbstrDoubleList<Oblast> oblasti = new AbstrDoubleList<>();
    private int maxKapacita = 1;
    private int oblastId = 1;

    @Override
    public void init(int maxKapacita) {
        this.maxKapacita = maxKapacita;
        oblasti.zrus();
        oblasti.vlozPrvni(new Oblast(oblastId++, maxKapacita));
    }

    @Override
public void automat(String soubor) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(soubor));
            for (String line : lines) {
                // P��klad instrukce na ��dku: "vloz 1 Jmeno" nebo "odeber PRVNI" apod.
                String[] parts = line.split("\\s+");
                if (parts.length > 0) {
                    switch (parts[0].toLowerCase()) {
                        case "vloz":
                            // vloz <id> <jmeno>
                            if (parts.length >= 3) {
                                int id = Integer.parseInt(parts[1]);
                                String jmeno = parts[2];
                                this.vlozZaznam(new Zaznam(id, jmeno));
                            }
                            break;
                        case "odeber":
                            // odeber <pozice>
                            if (parts.length >= 2) {
                                enumPozice pozice = enumPozice.valueOf(parts[1].toUpperCase());
                                this.odeberZaznam(pozice);
                            }
                            break;
                            // lze doplnit dal�� p��kazy
                    }
                }
            }   } catch (IOException ex) {
            Logger.getLogger(SpravaOblasti.class.getName()).log(Level.SEVERE, null, ex);
        }
}

    @Override
    public Oblast zpristupniOblast(enumPozice pozice) {
        switch (pozice) {
            case PRVNI: return oblasti.zpristupniPrvni();
            case POSLEDNI: return oblasti.zpristupniPosledni();
            case NASLEDNIK: return oblasti.zpristupniNaslednika();
            case PREDCHUDCE: return oblasti.zpristupniPredchudce();
            case AKTUALNI: return oblasti.zpristupniAktualni();
            default: throw new IllegalArgumentException();
        }
    }

    @Override
    public void vlozZaznam(Zaznam zaznam) {
        for (Oblast oblast : oblasti) {
            if (!oblast.jePlna()) {
                oblast.getZaznamy().vlozPosledni(zaznam);
                oblast.zvysKapacitu();
                return;
            }
        }
        // V�echny oblasti jsou pln�, vytvo��me novou
        Oblast nova = new Oblast(oblastId++, maxKapacita);
        nova.getZaznamy().vlozPosledni(zaznam);
        nova.zvysKapacitu();
        oblasti.vlozPosledni(nova);
    }

    @Override
    public void vlozZaznamPozice(Zaznam zaznam, enumPozice pozice) {
        Oblast oblast = oblasti.zpristupniAktualni();
        if (oblast.jePlna()) throw new IllegalStateException("Oblast je pln�");
        switch (pozice) {
            case PRVNI: oblast.getZaznamy().vlozPrvni(zaznam); break;
            case POSLEDNI: oblast.getZaznamy().vlozPosledni(zaznam); break;
            case NASLEDNIK: oblast.getZaznamy().vlozNaslednika(zaznam); break;
            case PREDCHUDCE: oblast.getZaznamy().vlozPredchudce(zaznam); break;
            default: throw new IllegalArgumentException();
        }
        oblast.zvysKapacitu();
    }

    @Override
    public Zaznam zpristupniZaznam(enumPozice pozice) {
        Oblast oblast = oblasti.zpristupniAktualni();
        return oblast.getZaznamy().zpristupniZaznam(pozice);
    }

    @Override
    public Zaznam odeberZaznam(enumPozice pozice) {
        Oblast oblast = oblasti.zpristupniAktualni();
        Zaznam z = oblast.getZaznamy().odeberZaznam(pozice);
        oblast.snizKapacitu();
        if (oblast.getAktKapacita() == 0) {
            oblasti.odeberAktualni();
        }
        return z;
    }

    @Override
    public void zrus() {
        oblasti.zrus();
        oblastId = 1;
    }

    @Override
    public Iterator<Oblast> iterator() {
        return oblasti.iterator();
    }
    
    
}
