/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Iterator;
import ds.*;

public class SpravaZaznamu implements ISpravaZaznamu {
    private final AbstrDoubleList<Zaznam> seznam = new AbstrDoubleList<>();

    @Override
    public void vlozZaznam(Zaznam zaznam, enumPozice pozice) {
        switch (pozice) {
            case PRVNI: seznam.vlozPrvni(zaznam); break;
            case POSLEDNI: seznam.vlozPosledni(zaznam); break;
            case NASLEDNIK: seznam.vlozNaslednika(zaznam); break;
            case PREDCHUDCE: seznam.vlozPredchudce(zaznam); break;
            default: throw new IllegalArgumentException();
        }
    }
    @Override
    public Zaznam zpristupniZaznam(enumPozice pozice) {
        switch (pozice) {
            case PRVNI: return seznam.zpristupniPrvni();
            case POSLEDNI: return seznam.zpristupniPosledni();
            case NASLEDNIK: return seznam.zpristupniNaslednika();
            case PREDCHUDCE: return seznam.zpristupniPredchudce();
            case AKTUALNI: return seznam.zpristupniAktualni();
            default: throw new IllegalArgumentException();
        }
    }
    @Override
    public Zaznam odeberZaznam(enumPozice pozice) {
        switch (pozice) {
            case PRVNI: return seznam.odeberPrvni();
            case POSLEDNI: return seznam.odeberPosledni();
            case NASLEDNIK: return seznam.odeberNaslednika();
            case PREDCHUDCE: return seznam.odeberPredchudce();
            case AKTUALNI: return seznam.odeberAktualni();
            default: throw new IllegalArgumentException();
        }
    }
    @Override
    public void zrus() { seznam.zrus(); }
    @Override
    public Iterator<Zaznam> iterator() { return seznam.iterator(); }
}
