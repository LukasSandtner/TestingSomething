/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.util.Iterator;

public interface ISpravaOblasti extends Iterable<Oblast> {
    void init(int maxKapacita);
    void automat(String soubor);
    Oblast zpristupniOblast(enumPozice pozice);
    void vlozZaznam(Zaznam zaznam); // first-fit
    void vlozZaznamPozice(Zaznam zaznam, enumPozice pozice);
    Zaznam zpristupniZaznam(enumPozice pozice);
    Zaznam odeberZaznam(enumPozice pozice);
    void zrus();
    Iterator<Oblast> iterator();
}
