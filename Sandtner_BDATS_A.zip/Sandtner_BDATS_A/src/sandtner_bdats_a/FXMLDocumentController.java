package sandtner_bdats_a;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.*;
import ds.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javafx.stage.FileChooser;
import javafx.stage.Window;

public class FXMLDocumentController {

    @FXML
    private TextField kapacitaField, zaznamJmenoField, zaznamIdField;
    @FXML
    private TextArea outputArea;
    @FXML
    private ComboBox<String> poziceBox;

    private final SpravaOblasti sprava = new SpravaOblasti();

    @FXML
    private void initialize() {
        poziceBox.getItems().addAll("PRVNI", "POSLEDNI", "NASLEDNIK", "PREDCHUDCE", "AKTUALNI");
        poziceBox.getSelectionModel().selectFirst();
    }

    @FXML
    private void onInitOblast() {
        int kap = Integer.parseInt(kapacitaField.getText());
        sprava.init(kap);
        outputArea.appendText("Inicializov�na oblast s kapacitou: " + kap + "\n");
        vypisOblasti();
    }

    @FXML
    private void onVlozZaznam() {
        int id = Integer.parseInt(zaznamIdField.getText());
        String jmeno = zaznamJmenoField.getText();
        Zaznam z = new Zaznam(id, jmeno);
        try {
            sprava.vlozZaznam(z);
            outputArea.appendText("Vlo�en z�znam (first-fit): " + z + "\n");
            vypisOblasti();
        } catch (Exception e) {
            outputArea.appendText("Chyba: " + e.getMessage() + "\n");
        }
    }

    @FXML
    private void onVlozZaznamPozice() {
        int id = Integer.parseInt(zaznamIdField.getText());
        String jmeno = zaznamJmenoField.getText();
        Zaznam z = new Zaznam(id, jmeno);
        try {
            sprava.vlozZaznamPozice(z, model.enumPozice.valueOf(poziceBox.getValue()));
            outputArea.appendText("Vlo�en z�znam do oblasti na pozici: " + poziceBox.getValue() + " - " + z + "\n");
            vypisOblasti();
        } catch (Exception e) {
            outputArea.appendText("Chyba: " + e.getMessage() + "\n");
        }
    }

    @FXML
    private void onOdeberZaznam() {
        try {
            Zaznam z = sprava.odeberZaznam(model.enumPozice.valueOf(poziceBox.getValue()));
            outputArea.appendText("Odebr�n z�znam: " + z + "\n");
            vypisOblasti();
        } catch (Exception e) {
            outputArea.appendText("Chyba: " + e.getMessage() + "\n");
        }
    }

    @FXML
    private void onZrus() {
        sprava.zrus();
        outputArea.appendText("V�e zru�eno\n");
        vypisOblasti();
    }

    private void vypisOblasti() {
        outputArea.appendText("Oblasti a jejich z�znamy:\n");
        for (Oblast o : sprava) {
            outputArea.appendText(o.toString() + ": ");
            for (Zaznam z : o.getZaznamy()) {
                outputArea.appendText(z.toString() + "; ");
            }
            outputArea.appendText("\n");
        }
    }

    @FXML
    private void onUlozVystup() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Ulo�it v�stup do souboru");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Textov� soubory", "*.txt"),
                new FileChooser.ExtensionFilter("V�echny soubory", "*.*")
        );
        Window window = outputArea.getScene().getWindow();
        File file = fileChooser.showSaveDialog(window);
        if (file != null) {
            try (FileWriter fw = new FileWriter(file)) {
                fw.write(outputArea.getText());
            } catch (IOException e) {
                outputArea.appendText("Chyba p�i ukl�d�n�: " + e.getMessage() + "\n");
            }
        }
    }

    @FXML
    private void onNactiSoubor() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Na��st vstupn� soubor");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Textov� soubory", "*.txt"),
                new FileChooser.ExtensionFilter("V�echny soubory", "*.*")
        );
        Window window = outputArea.getScene().getWindow();
        File file = fileChooser.showOpenDialog(window);
        if (file != null) {
            try {
                sprava.automat(file.getAbsolutePath());
                outputArea.appendText("Na�ten a zpracov�n vstupn� soubor: " + file.getName() + "\n");
                vypisOblasti();
            } catch (Exception e) {
                outputArea.appendText("Chyba p�i na��t�n�/zpracov�n�: " + e.getMessage() + "\n");
            }
        }
    }

}
