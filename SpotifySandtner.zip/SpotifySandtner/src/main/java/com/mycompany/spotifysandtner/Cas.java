/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.spotifysandtner;

/**
 *
 * @author st75720
 */
public class Cas {

    private final int minuty;
    private final int sekundy;

    public Cas(int minuty, int sekundy) {
        this.minuty = minuty;
        this.sekundy = sekundy;
    }

    public int prevedNaSekundy() {
        return sekundy + (minuty * 60);
    }

    @Override
    public String toString() {
        return "Cas{" + "minuty=" + minuty + ", sekundy=" + sekundy + '}';
    }
    
    
}
