/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.spotifysandtner;

import java.io.IOException;

/**
 *
 * @author st75720
 */
public class SpotifySandtner {

    public static void main(String[] args) {
        Playlist playlist = new Playlist(10, "Muj Playlist");
        playlist.pridejSong(new Song("Ja", "Song1", new Cas(2, 5), "rock"));
        playlist.pridejSong(new Song("Ty", "Song2", new Cas(1, 38), "pop"));

        try {
            playlist.nacistPlaylistZeSouboru("spotifydata.csv");
            playlist.ulozPlaylistDoSouboru("zapis.csv");
        } catch (IOException e) {
            System.out.println("Soubor nenacten" + e);
        }
        playlist.vypisSongy();
        System.out.println("\n");
        playlist.vypisSongy("pop");

        Song nejdelsi = playlist.najdiNejdelsiSkladbu();
        System.out.println("Nejdelsi skladba: " + nejdelsi.getNazev());

        int cas = playlist.delkaPlaylistu();
        System.out.printf("playlist ma %d s", cas);
        
        System.out.println("\n");
        playlist.nahodneZamichej();
        playlist.vypisSongy();
    }

}
