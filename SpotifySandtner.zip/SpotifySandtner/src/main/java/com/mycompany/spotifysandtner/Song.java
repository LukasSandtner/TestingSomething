/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.spotifysandtner;

/**
 *
 * @author st75720
 */
public class Song {
    private final String intepret;
    private final String nazev;
    private final Cas delka;
    private final String zanr;

    public Song(String intepret, String nazev, Cas delka, String zanr) {
        this.intepret = intepret;
        this.nazev = nazev;
        this.delka = delka;
        this.zanr = zanr;
    }

    public String getIntepret() {
        return intepret;
    }

    public String getNazev() {
        return nazev;
    }

    public Cas getDelka() {
        return delka;
    }

    public String getZanr() {
        return zanr;
    }
    
    public int casSekundy(){
        
        return delka.prevedNaSekundy();
    }

    @Override
    public String toString() {
        return (intepret + "; " + nazev + "; " + casSekundy() + "; " + zanr + "; ");
    }
}
