/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.spotifysandtner;

import java.io.*;

/**
 *
 * @author st75720
 */
public class Playlist {

    private final String jmeno;
    private final Song[] poleSongu;
    private int pocet;

    public Playlist(int pocetSongu, String jmeno) {
        poleSongu = new Song[pocetSongu];
        this.jmeno = jmeno;
        pocet = 0;
    }

    public void vypisSongy() {
        for (int i = 0; i < pocet; i++) {
            System.out.println(poleSongu[i].toString());
        }
    }

    public void vypisSongy(String zanr) {
        for (int i = 0; i < pocet; i++) {
            if (poleSongu[i].getZanr().equals(zanr)) {
                System.out.println(poleSongu[i].toString());
            } else {
                System.out.println("Zanr neexistuje.");
            }
        }
    }

    public void pridejSong(Song song) {
        if (pocet < poleSongu.length) {
            poleSongu[pocet++] = song;
        }
    }

    public void nahodneZamichej() {
        int nahoda = (int)(Math.random() * 10);
        for (int i = 0; i < pocet; i++) {
            if(i != nahoda){
                Song tmp = poleSongu[nahoda];
                poleSongu[nahoda] = poleSongu[i];
                poleSongu[i] = tmp;
            }
        }
        
    }

    public int delkaPlaylistu() {
        int suma = 0;

        for (int i = 0; i < pocet; i++) {
            suma += poleSongu[i].getDelka().prevedNaSekundy();
        }
        return suma;
    }

    public Song najdiNejdelsiSkladbu() {
        Song nejdelsi = poleSongu[0];
        for (int i = 1; i < pocet; i++) {
            if (nejdelsi.getDelka().prevedNaSekundy() < poleSongu[i].getDelka().prevedNaSekundy()) {
                nejdelsi = poleSongu[i];
            }
        }
        return nejdelsi;
    }

    public void nacistPlaylistZeSouboru(String nazevSouboru) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(nazevSouboru))) {
            String radek;
            int counter = 0;
            while ((radek = br.readLine()) != null) {
                radek = radek.trim();
                radek = radek.replace(" ", "");
                String[] data = radek.split(";");
                
                if (data.length == 4) {
                    String interpret = data[0];
                    String nazev = data[1];
                    String[] data2 = data[2].split(":");
                    int minuty = Integer.parseInt(data2[0]);
                    int vteriny = Integer.parseInt(data2[0]);
                    String zanr = data[3];
                    pridejSong(new Song(interpret, nazev, new Cas(minuty, vteriny), zanr));
                    counter++;
                } else {
                    System.out.println("Sptane nacteni dat na radku: " + counter);
                }
            }
        } catch (IOException e) {
            System.out.println("Chyba pri nacteni: " + e);
        }
    }

    public void ulozPlaylistDoSouboru(String nazevSouboru) throws IOException {
        try (BufferedWriter br = new BufferedWriter(new FileWriter(nazevSouboru))) {
            br.write("Playlist:");
            br.write(jmeno);
            br.newLine();
            for (int i = 0; i < pocet; i++) {
                br.write(poleSongu[i].toString());
                br.newLine();
            }

        } catch (IOException e) {
            System.out.println("Chyba pri zapisu: " + e);
        }
    }
}
