package cz.upce.fei.uloha11matice.matice;

import static cz.upce.fei.uloha11matice.matice.tool.PodporaMatic.napln2DPoleNahodne;

/**
 * Tato třída Matice je ukázkou třídy s kombinacemi instančních a třídních
 * metod. Dále zde bude procvičeno několik typů konstruktorů.
 * <p>
 * Matice, stejně jako číslo, má určitou hodnotu, kterou můžeme chápat jako stav
 * objektu. Proto by měla každá změna stavu objektu znamenat i vznik nového
 * objektu podle stejné třídy, tedy v našem případě od třídy Matice. Takovým
 * objektům říkáme, že jsou hodnotové.
 * <p>
 * Metody třídy nepotřebují k své činnosti instanci třídy, tedy objekt, patří
 * totiž již podle svého názvu ke třídě. Tyto metody jsou opatřeny modifikátorem
 * <code>static</code> a z jiných tříd se vyvolávají přes jméno jejích třídy.
 * <p>
 * Metody, které potřebují mít přístup ke stavu objektu, se nazývají instanční
 * metody. Tyto metody se neopatřují žádným modifikátorem s opačný významem k
 * modifikátoru <code>static</code> a ani není takový modifikátor k dispozici.
 * <p>
 * Na této třídě budou prezentovány základní vlastnosti členů třídy a jak lze
 * přistupovat k jejich návrhu.
 * <p>
 * Témata:
 * <ol>
 * <li>Kdo jsou členy třídy a kdo jsou členy instance, neboli objektu. </li>
 * <li>Čím je reprezentován stav objektu.</li>
 * <li>Jak se definují konstanty, kterými se vylučuje používání "magických
 * čísel" </li>
 * <li>Proč je vhodné neměnit stav objektu, ale raději vytvářet nové objekty s
 * provedenou změnou stavu.</li>
 * <li>Přetěžování konstruktorů a metod.</li>
 * <li>Co jsou to tovární (factory) metody a proč je používat.</li>
 * </ol>
 *
 *
 */
public class Matice implements IMatice {

// ==== Sekce instančních proměnných (atributů) ================================
    /* -------------------------------------------------------------------------
    Instanční proměnné (též atributy) jsou proměnné, pro které se vyhradí 
    v paměti nové místo pro každou novou instancí.
    --------------------------------------------------------------------------*/
    /**
     * Instanční proměnné (atributy) se převážně deklarují jako privátní a mohou
     * tvořit stav objektu. Definice (inicializace) těchto proměnných se
     * většinou provádí v konstruktorech. Pokud se neprovede inicializace, tak
     * takové atributy mají nulovou hodnotu nebo obsahují hodnotu
     * <code>null</code>. A to proto, že při vzniku instance se celé paměťové
     * místo pro atributy vynuluje. Tím je zajištěna počáteční inicializace
     * všech instančních proměnných (atributů).
     * <p>
     * Pokuď atribut se po definici dál nemění žádnou metodou třídy, je dobré
     * takový atribut opatřit modifikátorem <code>final</code>, který zabezpečí
     * kontrolu již v době překladu, že atribut nebude měněn. Je to dobrá
     * programátorská praktika, která zvyšuje bezpečnost zdrojových kódů.
     * <p>
     * Poznámky:
     * <ol>
     * <li>
     * Atribut <code>matrix</code> je jen referenční proměnná na dvojrozměrné
     * pole a jen jeho hodnota je po inicializaci v konstruktorech dále
     * nemměná.</li>
     * <li>
     * Toto opatření nám znemožňuje vyměnit pole za jiné. Proto bychom museli
     * implementovat v této třídě případnou metodu
     * <code>set(int[][] pole)</code> tak, že obsah vstupního pole budeme muset
     * nuceně pouze překopírovat. Tím se zapezpečí to, že obsah pole zůstane
     * skrytý a tím pádem chraněn před vnějšími úpravami. </li>
     * <ul>
     * <li>Kdybychom pouze převzali referenci, tak by mohl ten, kdo si ponechal
     * referenci na toto pole, kdykoliv obsah naší instance (objektu)
     * nekontrolovatelně měnit a ne jen obsah ale i rozměr. Což by znamenalo
     * katastrofu při používání našich objektů za běhu programu.
     * </li>
     * </ul>
     * <li>
     * Hodnoty prvků dvojrozměrného pole měnitelné jsou!</li>
     * <li> V našem případě jsou dva atributy s rozměry sice nabytečné, protože
     * lze tu samou informaci zjistit přímo z rozměrů pole díky jejich
     * atributů <code>length</code>. Požití atributů s rozměry dvojrozměrného
     * pole přehledňuje zdrojový kód třídy.
     * </li>
     * </ol>
     */
    private final int[][] matrix;    // referenční proměnná na dvojroměrné pole
    private final int pocetRadku;
    private final int pocetSloupcu;

// ==== Sekce konstruktorů =====================================================   
    /* -------------------------------------------------------------------------
     * Tato sekce demonstruje celou škálu přetížených, veřejných a privátních
       konstruktorů a jak lze tyto konstruktory řetězově spouštět.
      ------------------------------------------------------------------------*/
    /**
     * Konstrukce instance třídy <code>Matice</code> podle dvojrozměrného pole.
     * <p>
     * <b>Postup:</b>
     * <ol type="A">
     * <li>Konstruktor nejříve zkontroluje, zda vstupní dvojrozměrné pole má
     * rozměry v povolených mezích</li>
     * <li>Pak zkontroluje, zda všechny řádky pole jsou stejně dlouhé.</li>
     * <li>Po úspěšné kontole konstruktor překopíruje vstupní 2D pole do nové
     * instance a uloží její referencí do atributu. </li>
     * <li>Konstruktor dokončí inicializaci atributů s rozměry matice.</li>
     * </ol>
     * <p>
     * <b>Upozornění:</b>
     * <p>
     * V této metodě bude procvičeno klíčové slovo <code>this</code>, které
     * slouží k rozlišení přístupu k instančním proměnným od identifikátorů
     * parametrů metod nebo konstruktorů, které obvykle pojmenováme shodně.
     *
     * @param matrix Reference na dvojrozměrné pole s obsahem, kterým se naplní
     * instance třídy (objekt) <code>Matice</code>.
     *
     * @throws IllegalArgumentException Výjímka se vystaví v případě
     * nevyhovující kontroly vstupního parametru.
     */
    public Matice(int[][] matrix) throws IllegalArgumentException {
        // TODO podle kontraktu konstruktoru upravte kód 
        // tento kod je pouze z důvodu, aby syntaxe byla bez chyb - vyměnit za řešení       
        this.matrix = new int[0][0];
        pocetRadku = 0;
        pocetSloupcu = 0;
    }

    /**
     * Kopírovací konstruktor.
     * <p>
     * Kopírovací konstuktor slouží k vytoření nové instanace podle jiné
     * instance stejného typu. V našem případě vytvoříme druhou instanci matice
     * se stejným rozměrem a obsahem.
     * <p>
     * Postup:
     * <ol type="A">
     * <li>Tento konstruktor v našem případě je velmi jednoduchý, protože se v
     * něm dá zavolat jiný přetížený konstuktor a to <code>Matice(int[][]
     * matrix)</code>.</li>
     * <li>Argumentem ve volání přetíženého konstruktoru bude přímo reference na
     * skrytý atribut vnitřního pole ze vzorové instance.
     * <ul>
     * <li>To je umožněno tím, že se pohybujeme stále v rámci jedné třídy. Toto
     * je další z mnoha důležitých poznatků o třídách a objektech v
     * programovacích jazycích.</li>
     * </ul>
     * </li>
     * </ol>
     *
     *
     * @param m Reference na jinou (vzorovou) instanci třídy
     * <code>Matice</code>.
     */
    public Matice(Matice m) {
        /* TODO Kopírovací konstruktor doplňte o volání přetíženého konstruktoru.
        Jako argument použijte pole z parametru. 
        I když v parametru m je reference na jiný objekt, ale protože je stejného
        typu, tak můžeme přistoupit i k přivátním členům. V našem případě k 
        atributu matrix.
        Dále si v tomto kostruktoru vyzkoušíme použití klíčového slova this.
        Tělo konstruktoru bude obsahovat pouze jeden příkaz.
        */
        // tento kod je pouze z důvodu, aby syntaxe byla bez chyb - vyměnit za řešení
        this.matrix = new int[0][0];
        pocetRadku = 0;
        pocetSloupcu = 0;
    }

    /**
     * Privátní konstruktor vytvoří místo pro dvojrozměrnou matici.
     * <p>
     * Někdy je výhodnější přístup ke konstruktorům skrýt a volat ho jen z
     * veřejných metod třídy, kterým se říká "tovární (factory)" metody. Tovární
     * metody jsou uvedeny v následující sekci této třídy.
     * <p>
     * Tento konstruktor umožňuje vytvořit jen základní strukturu objektu,
     * protože nemůže naplnit obsah dvojrozměrné matice.
     * <p>
     * <b>Postup:</b>
     * <ol type="A">
     * <li >Nejdříve se provede kontrola hodnot vstupních parametrů na povolené
     * rozměry vytvářené matice.</li>
     * <li>V případě, že kontrola dopadne dobře tak:</li>
     * <ol type="a">
     * <li>Provede se vytvoření dvorozměrného pole.</li>
     * <li>Doplní se inicializace instančních proměnných s rozměrem matice.</li>
     * </ol>
     * <li> V případě, že kontrola rozměru nedopadla dobře tak:</li>
     * <ol type="a">
     * <li>Vystaví se výjimka.</li>
     * </ol>
     * </ol>
     *
     * @param radky Počet řádků matice.
     * @param sloupce Počet sloupců matice.
     *
     * @throws IllegalArgumentException Výjimka se vystaví v případě, že rozměry
     * matice nejsou v povolených mezích.
     */
    private Matice(int radky, int sloupce) throws IllegalArgumentException {
        // TODO Podle kontraktu implementujte konstruktor   
               
        // tento kod je pouze z důvodu, aby syntaxe byla bez chyb - vyměnit za řešení
        matrix = new int[0][0];
        pocetRadku = 0;
        pocetSloupcu = 0;
    }

    /**
     * Privatní konstruktor vytvoří instanci čtvercové matice.
     *
     * @param rozmer Rozměr čtvercové matice.
     */
    private Matice(int rozmer) {
        /* TODO Doplňte volání přetíženého konstruktoru
           Doplňuje se pouze jeden řádek kódu.
         */
        // tento kod je pouze z důvodu, aby syntaxe byla bez chyb - vyměnit za řešení
        matrix = new int[0][0];
        pocetRadku = 0;
        pocetSloupcu = 0;
    }

// ==== Sekce továrních metod ==================================================  
    /* ------------------------------------------------------------------------- 
       Sekce továrních metod je zde uvedena jako ukázka využití metod tříd. 
       Ve standartních knihovnách javy se metody tříd velmi vyžívají, příkladem
       může být třída Math. Ve třídě Arrays je zase tovární tato metoda:
                public static <T> List<T> asList(T... a) {
                    return new ArrayList<>(a);
                }
       Tovární metody se používají taky tehdy, když chceme ještě před vyvoláním
       konstruktoru zavolat jinou metodu, která například připraví data pro
       konstruktor.    
       Tovární metody mohou zrychlit běh programu, protože konstrukce objektu
       je časově náročná. Říká se, že konstruktora je drahý.
    --------------------------------------------------------------------------*/
    /**
     * Tovární metoda na vytvoření čtvercovou matici podle pole
     * 
     * 
     *
     * @param matrix Parametr s referencí na dvojrozměrné pole daty.
     *
     * @return Vrací referenci na novou instanci nové čtvercové matice.
     */
    public static Matice vytvorCtvercovouMatici(int[][] matrix) {
        // TODO Doplňte volání privátního konstruktoru        
        return null;
    }

    /**
     * Tovární metoda na vytvoření matice s náhodným obsahem buňek.
     *
     * @param pocetRadku
     * @param pocetSloupcu
     * @param minimum // minumum náhodných čísel
     * @param maximum // maximum náhodných čísel
     *
     * @return Vrací referenci na novou instanci matice s nahodným obsahem.
     */
    public static Matice vytvorMaticiNahodne(
            int pocetRadku, int pocetSloupcu,
            int minimum, int maximum) {
        int[][] pole = napln2DPoleNahodne(pocetRadku, pocetSloupcu, minimum, maximum);
        return new Matice(pole);
    }

    /**
     * Tovární metoda na vytvoření matice s náhodným obsahem buňek.
     * <p>
     * Tato varianta tovární metody je ukázkou, že lze nastavit obsah matice po
     * po vytvoření instance konstruktorem.
     *
     * @param pocetRadku
     * @param pocetSloupcu
     * @param minimum // minumum náhodných čísel
     * @param maximum // maximum náhodných čísel
     *
     * @return Vrací referenci na novou instanci matice s nahodným obsahem.
     */
    public static Matice vytvorMaticiNahodne2(
            int pocetRadku, int pocetSloupcu,
            int minimum, int maximum) {
        Matice m = new Matice(pocetRadku, pocetSloupcu);
        int[][] pole = napln2DPoleNahodne(pocetRadku, pocetSloupcu, minimum, maximum);
        for (int i = 0; i < pole.length; i++) {
            System.arraycopy(pole[i], 0, m.matrix[i], 0, pole[i].length);
        }
        return m;
    }

// ==== Sekce veřejných zjišťovacích instančních metod =========================    
    /* -------------------------------------------------------------------------
      Zjišťovací metody pouze poskytují požadované informace o objektu a přičemž
      nemění jeho stav 
       ---------------------------------------------------------------------- */
    /**
     * Zjišťovací metoda kolik má matice řádků.
     * <p>
     * Metoda nemusí obsahovat test na nepovolenou hodnotu, protože tato
     * kontrola byla provedena při konstrukci objektu. To samé platí i pro
     * druhou metodu, která zjišťuje počet sloupců.
     *
     * @return Vrací počet řádků matice.
     */
    @Override
    public int getPocetRadku() {
        return pocetRadku;
    }

    /**
     * Zjišťovací metoda kolik má matice sloupců.
     * <p>
     * @return Vrací počet sloupců matice.
     */
    @Override
    public int getPocetSloupcu() {
        return pocetSloupcu;
    }

    /**
     * Zjišťovací metoda, zda matice je čtvercová.
     * <p>
     * Pozmámka:
     * <ol>
     * <li>Před implementaci takové funkce je vhodné si prohlédnou ostatní
     * metody třídy, zda by se na podobnou kontrolu nemohla některá z nich
     * použít. Zároveň by taková metoda mohla mít vícenásobné použití. Tímto
     * přístupem k návrhu metod se vyhýbáme duplicitám v kódu.
     * </li>
     * <li>
     * V našem případě se bude jednat o metodu
     * <code>kontrolaShodyRozmeru</code>, která bude volána se dvěmi stejnými
     * parametry.
     * </li>
     * <li>
     * Obvykle takové metody přebírají vstupní údaje z parametrů a výsledek
     * vrací při ukončení. Takové metody nepotřebují stav objektu a proto můžou
     * to být metody třídy, tj. s modifikátorem <code>static</code>. Takové
     * metody jsou efektivnější, protože nemají přístup k instančním proměnným.
     * </li>
     * </ol>
     *
     * @return Vrací <code>true</code>, když je matice čtvercová, jinak vrací
     * <code>false</code>.
     */
    @Override
    public boolean isCtvercovaMatice() {
        /* TODO Dopňte kontrolu, zda se jedná o čtvercovou matici.
           Doplňuje se pouze jeden řádek kódu s voláním vhodné metody.
         */
        return kontrolaShodyRozmeru(this.pocetRadku, this.pocetSloupcu);
    }
// ==== Přetížené metody´=======================================================

    /* -------------------------------------------------------------------------
     * Přetěžování metod je obvyklý způsob jak zbytečně nerozšiřovat jména pro
     * metody se stejnou odpovědností, ale s různými vstupními parametry.
     * <p>
     * Přetížené metody musí mít rozdílnou signaturu. TO znamená, že metody mají
     * rozdilný počet parametrů nebo při stejném počtu parametrů musí alespoň
     * jeden stejnolehlý parametr se lišit v typu.
     * -------------------------------------------------------------------------
     */
    /**
     * Metoda sestaví textový řetězec s obsahem matice.
     * <p>
     * Výstupní řetězec se sestavuje po řádcích tak, aby každý řádek matice byl
     * na jednom řádku textu.
     *
     * @param format Formát pro převod čísla na text.
     *
     * @return Výsledný textový řetězec s obsahem matice.
     */
    @Override
    public String toString(String format) {
        if (format == null) {
            throw new NullPointerException("");
        }
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < pocetRadku; i++) {
            for (int j = 0; j < pocetSloupcu; j++) {
                str.append(String.format(format, matrix[i][j]));
            }
            str.append('\n');
        }
        return str.toString();
    }

    @Override
    public String toString() {
        /* TODO Doplňte volání přetížené metody toString s argumentem "%3d ".
            Doplňuje se pouze jeden řádek kódu s voláním vhodné metody.
         */
        return toString("%3d ");
    }
// ==== Akční metody ===========================================================

    /**
     * Nulování sloupce matice
     * <p>
     * Postup:
     * <ol type="A">
     * <li>
     * </ol>
     *
     * @param sloupec Index sloupce matice, který se má vynulovat.
     *
     * @return Vrací zkopirovaný objekt s vynulovaným sloupcem.
     */
    public Matice nulujSloupec(int sloupec) {
        // TODO Implementujte metodu podle kontraktu.
        if (!(MINIMALNI_ROZMER <= sloupec && sloupec <= this.pocetSloupcu)) {
            throw new IllegalArgumentException("Hodnota sloupce.");
        }
        Matice m = new Matice(matrix);
        for (int i = 0; i < m.pocetRadku; i++) {
            m.matrix[i][sloupec] = 0;
        }
        return m;
    }

    /**
     * Nulování hlavní diagonály matice
     * <p>
     * Upozornění:
     * <p>
     * Hlavní diagonála je i u obdélníkových matic, kdy se musí dávat pozor na
     * to, zda diagonála končí na posledním sloupci nebo na posledním řádku.
     *
     *
     * @return Instance nove matice s upraveným obsahem
     */
    @Override
    public Matice nulujDiagonalu() {
        // TODO Doplńte vynulov8ní hlavní diagonály
        Matice m = new Matice(matrix);
        for (int i = 0; i < m.pocetRadku; i++) {
            m.matrix[i][i] = 0;
        }
        return m;
    }

    /**
     *
     * @return
     */
    @Override
    public Matice prohodPodleHlavniDiagonaly() {
        Matice m = new Matice(matrix);
        for (int i = 0; i < m.pocetRadku - 1; i++) {
            for (int j = i + 1; j < m.pocetSloupcu; j++) {
                int p = m.matrix[i][j];
                m.matrix[i][j] = m.matrix[j][i];
                m.matrix[j][i] = p;
            }
        }
        return m;
    }

// ==== Sekce privátních metod ================================================= 
    /* -------------------------------------------------------------------------
       Sekce privátních metod se doporučuje oddělit od veřejných metod. Veřejné
       metody tvoří rozhraní a proto by se neměly míchat s privátními metodami.
       Zvyšuje to přehlednost zdrojového kódu.
       Privátní metody podporují činnost veřejných metod a slouží ke skrývání
       implementace. Věřejné metody lze totiž, pokud to není vyloženě zakázáno 
       modifikátorem final, snadno překrýt v potomcích a to potom může výrazně
       ovlivňovat funkci ostatních veřejných metod třídy a hlavně to může mít
       zásadní vliv na konstruktory. Proto když to NetBeans zjistí, zobrazí
       varovné hlášení.
    --------------------------------------------------------------------------*/
    /**
     * Metoda kontroly, zda je počet řádků roven počtu sloupců.
     *
     * @param pocetRadku
     * @param pocetSloupcu
     *
     * @return Vrací <code>true</code>, když je počet sloupců roven počtu řádků,
     * jinak vrací <code>false</code>.
     */
    private static boolean kontrolaShodyRozmeru(int pocetRadku, int pocetSloupcu) {
        return pocetRadku == pocetSloupcu;
    }

    /**
     * Metoda zjišťuje, zda rozměry řádků a sloupců jsou v povoleném rozsahu.
     * <p>
     * Povolený rozsah pro oba dva rozměry je stejný a je dán dvěmi konstantami
     * <code>MINIMALNI_ROZMER</code> a <code>MAXIMALNI_ROZMER</code>.
     *
     * @param radky
     * @param sloupce
     *
     * @return Vrací <code>true</code>, když je hodnota řádku a sloupce v
     * povoleném rozsahu, jinak vrací <code>false</code>.
     */
    private static boolean kontrolaRozmeruRozsahem(int radky, int sloupce) {
        /* TODO Doplňte výraz kontroly rozsahu řádků a sloupců.
           Požaduje se implementovat pouze jeden výraz, jehož
           vyhodnocená hodnota se přímo použije v příkazu <code>return</code>.
         */
        return MINIMALNI_ROZMER <= radky && radky < MAXIMALNI_ROZMER
                && MINIMALNI_ROZMER <= sloupce && sloupce < MAXIMALNI_ROZMER;
    }

    /**
     * Kontrola rozměru dvojrozměrného pole.
     *
     * @param matrix Parametr s referencí na dvojrozměrné pole.
     *
     * @return Vrací <code>true</code>, když jsou oba dva rozměry pole v
     * povolených rozsazích, jinak vrací <code>false</code>.
     */
    private static boolean kontrolaRozmeruMatrix(int[][] matrix) {
        if (MINIMALNI_ROZMER <= matrix.length && matrix.length < MAXIMALNI_ROZMER) {
            int delkaRadku = matrix[0].length;
            if (!(MINIMALNI_ROZMER <= delkaRadku && delkaRadku < MAXIMALNI_ROZMER)) {
                return false;
            }
            for (int[] matrix1 : matrix) {
                if (matrix1.length != delkaRadku) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Metoda kopírování dvojrozměrných polí.
     *
     * @param source reference na zdrojové pole
     * @param destination reference na cílové pole
     */
    private static void copyMatrix(int[][] source, int[][] destination) {
        if (kontrolaRozmeruMatrix(source) && kontrolaShodyRozmeru(source, destination)) {
            for (int i = 0; i < source.length; i++) {
                System.arraycopy(source[i], 0, destination[i], 0, source[i].length);
            }
        }

//        copy = Arrays.stream(m).map(r -> r.clone()).toArray(int[][]::new);
    }

    /**
     * Kontrola, zda jsou rozměry dvou polí shodné.
     *
     * @param matrix1
     * @param matrix2
     *
     * @return Vrací <code>true</code>, když dvě pole se shodují obou dvou
     * rozměrech, jinak <code>false</code>.
     */
    private static boolean kontrolaShodyRozmeru(int[][] matrix1, int[][] matrix2) {
        return matrix1.length == matrix2.length && matrix1[0].length == matrix2[0].length;
    }

}