package cz.upce.fei.uloha11matice.matice.tool;

import cz.upce.fei.uloha11matice.matice.IMatice;
import cz.upce.fei.uloha11matice.matice.Matice;





public final class PodporaMatic {

    private PodporaMatic() {
    }

    /**
     * Tovární metoda na vytvoření matice obsahem buňek podle indexů.
     *
     * @param pocetRadku
     * @param pocetSloupcu
     *
     * @return Vrací referenci na novou instanci matice s obsahem podle indexů.
     */
    public static IMatice vytvorMaticiIndex(int pocetRadku, int pocetSloupcu) {
        int[][] pole = napln2DPolePodleIndexu(pocetRadku, pocetSloupcu);
        return new Matice(pole);
    }

 
    /**
     * Metoda na vytvoření dvojrozměrného pole s náhodným obsahem
     *
     * @param pocetRadku
     * @param pocetSloupcu
     * @param minimum
     * @param maximum
     *
     * @return Vrací referenci na vytvořené pole.
     */
    public static int[][] napln2DPoleNahodne(
            int pocetRadku, int pocetSloupcu, int minimum, int maximum) {

        int[][] pole = new int[pocetRadku][pocetSloupcu];

        for (int i = 0; i < pocetRadku; i++) {
            for (int j = 0; j < pocetSloupcu; j++) {
                pole[i][j] = (int) Math.round(Math.random() * (maximum - minimum)
                        + minimum);
            }
        }
        return pole;
    }

    /**
     * Metoda na vytvoření dvojrozměrného pole s obsahem podle indexů.
     * <p>
     * Tento vzorek dat dvojrozměrného pole slouží k testování algoritmů, které
     * přesouvají hodnoty v poli. Tím, že hodnoty v buňkách obsahují indexy, lze
     * přesun snadno zkontrolovat, zda proběhl podle požadavků.
     *
     * @param pocetRadku
     * @param pocetSloupcu
     *
     * @return Vrací referenci na vytvořené pole.
     */
    public static int[][] napln2DPolePodleIndexu(int pocetRadku, int pocetSloupcu) {
//        if (kontrolaRozmeruRozsahem(pocetRadku, pocetSloupcu)) {
//            throw new IllegalArgumentException();
//        }
        int[][] pole = new int[pocetRadku][pocetSloupcu];
        int k = (pocetRadku < 10 && pocetSloupcu < 10) ? 10 : 100;
        for (int i = 0; i < pocetRadku; i++) {
            for (int j = 0; j < pocetSloupcu; j++) {
                pole[i][j] = k * i + j;
            }
        }
        return pole;
    }

}
