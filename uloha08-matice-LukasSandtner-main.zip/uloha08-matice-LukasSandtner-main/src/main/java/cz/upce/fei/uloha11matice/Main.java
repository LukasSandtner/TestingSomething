package cz.upce.fei.uloha11matice;

import cz.upce.fei.uloha11matice.matice.IMatice;
import static cz.upce.fei.uloha11matice.matice.tool.PodporaMatic.vytvorMaticiIndex;

public class Main {

    public static void main(String[] args) {
        IMatice m = vytvorMaticiIndex(5, 5);

        System.out.println(m);

        System.out.println("Nulovani diagonaly");
        IMatice m2 = m.nulujDiagonalu();
        System.out.println(m2.toString());

        System.out.println("Nulovani sloupce");
        m2 = m.nulujSloupec(2);
        System.out.println(m2.toString("%02d "));

        System.out.println("Prohozeni obsahu matice");
        m2 = m.prohodPodleHlavniDiagonaly();
        System.out.println(m2.toString("%02d "));

    }

}
