package cz.upce.fei.uloha11matice.matice;


public interface IMatice {

    int MAXIMALNI_ROZMER = 100;
    
    int MINIMALNI_ROZMER = 2;

    
    /**
     * Zjišťovací metoda kolik má matice řádků.
     * <p>
     * Metoda nemusí obsahovat test na nepovolenou hodnotu, protože tato
     * kontrola byla provedena při konstrukci objektu. To samé platí i pro
     * druhou metodu, která zjišťuje počet sloupců.
     *
     * @return Vrací počet řádků matice.
     */
    int getPocetRadku();

    /**
     * Zjišťovací metoda kolik má matice sloupců.
     * <p>
     * @return Vrací počet sloupců matice.
     */
    int getPocetSloupcu();

    /**
     * Zjišťovací metoda, zda matice je čtvercová.
     * <p>
     * Pozmámka:
     * <ol>
     * <li>Před implementaci takové funkce je vhodné si prohlédnou ostatní
     * metody třídy, zda by se na podobnou kontrolu nemohla některá z nich
     * použít. Zároveň by taková metoda mohla mít vícenásobné použití. Tímto
     * přístupem k návrhu metod se vyhýbáme duplicitám v kódu.
     * </li>
     * <li>
     * V našem případě se bude jednat o metodu
     * <code>kontrolaShodyRozmeru</code>, která bude volána se dvěmi stejnými
     * parametry.
     * </li>
     * <li>
     * Obvykle takové metody přebírají vstupní údaje z parametrů a výsledek
     * vrací při ukončení. Takové metody nepotřebují stav objektu a proto můžou
     * to být metody třídy, tj. s modifikátorem <code>static</code>. Takové
     * metody jsou efektivnější, protože nemají přístup k instančním proměnným.
     * </li>
     * </ol>
     *
     * @return Vrací <code>true</code>, když je matice čtvercová, jinak vrací
     * <code>false</code>.
     */
    boolean isCtvercovaMatice();
    
    
    /**
     * Nulování sloupce matice
     * <p>
     * Postup:
     * <ol type="A">
     * <li>
     * </ol>
     *
     * @param sloupec Index sloupce matice, který se má vynulovat.
     *
     * @return Vrací zkopirovaný objekt s vynulovaným sloupcem.
     */
    public IMatice nulujSloupec(int sloupec);
    
    
    /**
     * Nulování hlavní diagonály matice
     * <p>
     * Upozornění:
     * <p>
     * Hlavní diagonála je i u obdélníkových matic, kdy se musí dávat pozor na
     * to, zda diagonála končí na posledním sloupci nebo na posledním řádku.
     *
     *
     * @return Instance nove matice s upraveným obsahem
     */
    IMatice nulujDiagonalu();
    
   
    /**
     *
     * @return
     */
    IMatice prohodPodleHlavniDiagonaly();
    
    
    String toString(String format);
}
